// Se crean las constantes a utilizar de los modulos instalados
const express = require('express');
const mysql = require('mysql');
const myconn = require('express-myconnection');


// requerir routes.js, hace referencia al metodo en dicho archivo
const rutas = require('./routes');
const app = express();

// Se crean las opciones para conectar a MySQL, tal como lo indica la constante
const dbOptions = {
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: '',
    database: 'concredito'
};

// middlewares
app.use(myconn(mysql, dbOptions, 'single'));
app.use(express.json());
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
	res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});

// Se establece el puerto a utilizar o utiliza el puerto dado por el host
app.set('port', process.env.PORT || 9000);

// Routes
app.use('/api', rutas);

// Se hace una llamada al servidor para ver si está funcionando y se muestra en consola el mensaje
app.listen(app.get('port'), () => {
    console.log('Server on port', app.get('port'));
});