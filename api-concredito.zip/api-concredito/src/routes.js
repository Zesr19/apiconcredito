// Se crean las constantes express y se usa su función o modulo de Router para crear las rutas
const express = require('express');
const rutas = express.Router();
const multer = require('multer');
const mimeTypes = require('mime-types');

// Se usa multer para subir el archivo al servidor y se le cambia el bombre al archivo
const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: function(req, file, res){
        res("", Date.now() + '_' + file.originalname + "." + mimeTypes.extension(file.mimetype));
    }    
})

const upload = multer({
    storage: storage
})

// Rutas de la API

// Ruta para obtener el listado de los prospectos
rutas.get('/', (req, res) => {
    // se abre la conexión a la BD
    req.getConnection((err, conn) => {
        if(err) return res.send(err)

        //Se hace una consulta
        conn.query('SELECT A.Id, A.name, A.apellidoP, A.apellidoM, B.valor FROM prospectos AS A INNER JOIN estatus AS B WHERE A.IdEstado = B.IdEstado', (err, rows) => {
            if(err) return res.send(err)
            // Se responde con los resultados en formato Json
            res.json(rows)
        })
    })
})

// Ruta para mostrar los datos de un prospecto en especifico
rutas.get('/prospecto/:id', (req, res) => {    
    req.getConnection((err, conn) => {
        if(err) return res.send(err)

        conn.query('SELECT A.Id, A.name, A.apellidoP, A.apellidoM, A.calle, A.numero, A.colonia, A.CP, A.telefono, A.RFC, A.IdEstado, B.valor, A.comentarios FROM prospectos AS A INNER JOIN estatus AS B WHERE A.IdEstado = B.IdEstado AND A.Id = ?', [req.params.id], (err, row) => {
            if(err) return res.send(err)

            //Aquí obtendré los documentos
            conn.query('SELECT nameDoc FROM documentos WHERE IdProspectos = ?', [req.params.id], (err, rows)=>{
                if(err) return res.send(err)
                // Se agrega el arreglo de los documentos al arreglo original que contiene la información del prospecto
                row.push(rows)
                res.json(row)
            })
        })
    })
})

// Ruta para actualizar el estado de un prospecto (autorizar)
rutas.put('/autorizar/:id', (req, res) => {
    req.getConnection((err, conn) => {
        if(err) return res.send(err)
        
        conn.query('UPDATE prospectos set IdEstado = ? WHERE Id = ?', [req.body.IdEstado, req.params.id], (err, resp) => {
            if(err) return res.send(err)
            res.json({ mensaje: 'El prospecto ha sido autorizado'});
        })
    })
})

// Ruta para actualizar el estado de un prospecto (rechazar)
rutas.put('/rechazar/:id', (req, res) => {
    req.getConnection((err, conn) => {
        if(err) return res.send(err)
        
        conn.query('UPDATE prospectos set comentarios = ?, IdEstado = ? WHERE Id = ?', [req.body.comentarios, req.body.IdEstado, req.params.id], (err, resp) => {
            if(err) return res.send(err)
            res.json({ mensaje: 'El prospecto ha sido rechazado'});
        })
    })
})

// Ruta para insertar o registrar un nuevo prospecto
rutas.post('/registrar', upload.array('formFile[]'), (req, res) => {
    req.getConnection((err, conn) => {
        if(err) return res.send('Error 1: ' + err);
        
        conn.query('INSERT INTO prospectos set ?', [req.body], (err, resp) => {
            if(err) return res.send('Error 2: ' + err)

            // En esta consulta obtengo el ultimo id insertado en la BD
            conn.query('SELECT LAST_INSERT_ID() AS IdProspectos;', (err, idres) => {
                if(err) return res.send('Error 3: ' + err)

                // obtengo el Id recien insertado
                const idNewProspecto = idres[0].IdProspectos;

                // guardo los archivos como un array para utilizarlo con el foreach
                const arregloFiles = req.files;
                arregloFiles.forEach(element => {
                    //console.log(element.filename);
                    conn.query('INSERT INTO documentos set IdProspectos = ?, nameDoc = ?', [idNewProspecto, element.filename], (err, respuesta) => {
                        if(err) return res.send('Error 4: ' + err)
                        res.send('Prospecto registrado y archivos cargados al servidor!');
                    })
                });   
            })
        })
    })
})

/*
rutas.delete('/:id', (req, res) => {
    req.getConnection((err, conn) => {
        if(err) return res.send(err)
        
        conn.query('DELETE FROM prospectos WHERE Id = ?', [req.params.id], (err, rows) => {
            if(err) return res.send(err)
            res.send('Prospecto eliminado');
        })
    })
})
*/



module.exports = rutas;